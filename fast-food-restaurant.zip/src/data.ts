import { MenuItem } from "./types";

export const FALLBACK_MENU: MenuItem[] = [
  {
    id: "classic-burger",
    name: "Sizzle Classic",
    category: "burgers",
    price: 6.99,
    description: "Flame-grilled premium Aberdeen beef patty, signature house sauce, fresh leaf lettuce, heirloom tomato, pickles, and toasted brioche bun.",
    calories: 580,
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80",
    customizationOptions: {
      type: "burgers",
      options: ["patties", "cheese", "exclude_onions", "exclude_pickles", "extra_sauce"]
    }
  },
  {
    id: "cheese-burger",
    name: "Golden Cheddar Melt",
    category: "burgers",
    price: 8.49,
    description: "Double smash patty, melted aged Wisconsin cheddar cheese, honey-grilled sweet onions, Dijon mustard, and signature house spread.",
    calories: 790,
    image: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=600&q=80",
    customizationOptions: {
      type: "burgers",
      options: ["patties", "cheese", "exclude_onions", "exclude_pickles", "extra_sauce"]
    }
  },
  {
    id: "spicy-burger",
    name: "Volcano Crunch",
    category: "burgers",
    price: 8.99,
    description: "Crispy fried chicken breast dipped in hot Nashville chili oil, melted pepper-jack cheese, custom jalapeno-lime cream slaw, and pickled jalapeno.",
    calories: 720,
    image: "https://images.unsplash.com/photo-1625813506062-0aeb1d7a094b?auto=format&fit=crop&w=600&q=80",
    customizationOptions: {
      type: "burgers",
      options: ["patties", "cheese", "exclude_onions", "exclude_pickles", "extra_sauce"]
    }
  },
  {
    id: "garden-burger",
    name: "Avocado Smash Veggie",
    category: "burgers",
    price: 7.99,
    description: "Rich house-made fiber-packed grain & plant patty, fresh smashed Haas avocado, field organic baby greens, cucumber, and roasted garlic aioli.",
    calories: 460,
    image: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=600&q=80",
    customizationOptions: {
      type: "burgers",
      options: ["patties", "cheese", "exclude_onions", "exclude_pickles", "extra_sauce"]
    }
  },
  {
    id: "golden-fries",
    name: "Sizzle Salted Fries",
    category: "sides",
    price: 3.49,
    description: "Idaho russet potatoes twice fried to premium crisp perfection, seasoned with harvested sea salt flakes.",
    calories: 320,
    image: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=600&q=80",
    customizationOptions: {
      type: "sides",
      options: ["salt_level", "spice_dust"]
    }
  },
  {
    id: "truffle-fries",
    name: "Rosemary Truffle Fries",
    category: "sides",
    price: 4.99,
    description: "House-cut sea salt fries tossed in premium white truffle oil, hand-shaved Parmigiano-Reggiano, and fresh rosemary sprigs.",
    calories: 410,
    image: "https://images.unsplash.com/photo-1585109649139-366815a0d713?auto=format&fit=crop&w=600&q=80",
    customizationOptions: {
      type: "sides",
      options: ["salt_level", "spice_dust"]
    }
  },
  {
    id: "onion-rings",
    name: "Crispy Onion Rings",
    category: "sides",
    price: 3.99,
    description: "Jumbo sweet Texas onions double dipped in golden craft-beer batter, fried to light crunch, served with spicy BBQ brew dip.",
    calories: 380,
    image: "https://images.unsplash.com/photo-1639024471283-2bc7b3c6a267?auto=format&fit=crop&w=600&q=80",
    customizationOptions: {
      type: "sides",
      options: ["salt_level", "spice_dust"]
    }
  },
  {
    id: "byte-cola",
    name: "Premium Craft Cola",
    category: "beverages",
    price: 2.29,
    description: "Artisanal cola brewed, sweet cane sugar finish, carbonated to absolute crispness.",
    calories: 140,
    image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&w=600&q=80",
    customizationOptions: {
      type: "beverages",
      options: ["drink_size", "ice_level"]
    }
  },
  {
    id: "lemonade",
    name: "Mint Infused Lemonade",
    category: "beverages",
    price: 2.79,
    description: "Cold pressed organic lemons, raw simple cane sugar, chilled together with fresh fragrant garden mint leaves.",
    calories: 110,
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=600&q=80",
    customizationOptions: {
      type: "beverages",
      options: ["drink_size", "ice_level"]
    }
  },
  {
    id: "velvet-shake",
    name: "Velvet Milkshake",
    category: "beverages",
    price: 4.49,
    description: "Thick hand-spun double vanilla bean churned milkshake, topped with a cloud of whipped cream and caramelized waffle dust.",
    calories: 520,
    image: "https://images.unsplash.com/photo-1579954115545-a95591f28bfc?auto=format&fit=crop&w=600&q=80",
    customizationOptions: {
      type: "beverages",
      options: ["drink_size", "shake_flavor"]
    }
  },
  {
    id: "lava-cake",
    name: "Molten Fudge Cocoa Cake",
    category: "desserts",
    price: 5.49,
    description: "Warm single-origin dark chocolate cake structure surrounding an explosive volcano of hot liquid molten fudge.",
    calories: 450,
    image: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=600&q=80",
    customizationOptions: {
      type: "desserts",
      options: ["extra_drizzle"]
    }
  },
  {
    id: "cookie-skillet",
    name: "Deep Dish Chocolate Skillet",
    category: "desserts",
    price: 5.99,
    description: "Cast-iron baked premium brown butter brown sugar chocolate chunk cookie, soft and chewy center, topped with rock sea salt caramel drizzle.",
    calories: 540,
    image: "https://images.unsplash.com/photo-1585478259715-876acc5be8eb?auto=format&fit=crop&w=600&q=80",
    customizationOptions: {
      type: "desserts",
      options: ["extra_drizzle"]
    }
  }
];
