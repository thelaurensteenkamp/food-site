import { useState, useEffect } from "react";
import { MenuItem, ItemCustomizations } from "../types";
import { calculateItemPrice, getCustomizationSummary } from "../utils";
import { Plus, Minus, X, HelpCircle, Check, Info } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface MealCustomizerProps {
  item: MenuItem;
  onClose: () => void;
  onAddToCart: (item: MenuItem, quantity: number, customizations: ItemCustomizations) => void;
  initialCustomizations?: ItemCustomizations;
}

export default function MealCustomizer({
  item,
  onClose,
  onAddToCart,
  initialCustomizations
}: MealCustomizerProps) {
  const [quantity, setQuantity] = useState(1);
  const [customs, setCustoms] = useState<ItemCustomizations>({});

  // Initialize customizations depending on item category
  useEffect(() => {
    if (initialCustomizations) {
      setCustoms(initialCustomizations);
      return;
    }

    const defaultCustoms: ItemCustomizations = {};
    if (item.category === "burgers") {
      defaultCustoms.patties = item.id === "cheese-burger" ? 2 : 1;
      defaultCustoms.cheese = item.id === "cheese-burger" ? 2 : (item.id === "spicy-burger" ? 1 : 1);
      defaultCustoms.excludeOnions = false;
      defaultCustoms.excludePickles = false;
      defaultCustoms.extraSauce = false;
    } else if (item.category === "sides") {
      defaultCustoms.saltLevel = "regular";
      defaultCustoms.spiceDust = false;
    } else if (item.category === "beverages") {
      defaultCustoms.size = "M";
      defaultCustoms.iceLevel = "regular";
      if (item.id === "velvet-shake") {
        defaultCustoms.shakeFlavor = "Vanilla";
      }
    } else if (item.category === "desserts") {
      defaultCustoms.extraDrizzle = false;
    }
    setCustoms(defaultCustoms);
  }, [item, initialCustomizations]);

  const updateProp = (key: keyof ItemCustomizations, value: any) => {
    setCustoms(prev => ({ ...prev, [key]: value }));
  };

  const itemPrice = calculateItemPrice(item.price, item.category, customs);
  const totalCost = Number((itemPrice * quantity).toFixed(2));

  // Determine standard defaults for reset helper
  const handleReset = () => {
    const defaultCustoms: ItemCustomizations = {};
    if (item.category === "burgers") {
      defaultCustoms.patties = item.id === "cheese-burger" ? 2 : 1;
      defaultCustoms.cheese = item.id === "cheese-burger" ? 2 : 1;
      defaultCustoms.excludeOnions = false;
      defaultCustoms.excludePickles = false;
      defaultCustoms.extraSauce = false;
    } else if (item.category === "sides") {
      defaultCustoms.saltLevel = "regular";
      defaultCustoms.spiceDust = false;
    } else if (item.category === "beverages") {
      defaultCustoms.size = "M";
      defaultCustoms.iceLevel = "regular";
      if (item.id === "velvet-shake") {
        defaultCustoms.shakeFlavor = "Vanilla";
      }
    } else if (item.category === "desserts") {
      defaultCustoms.extraDrizzle = false;
    }
    setCustoms(defaultCustoms);
    setQuantity(1);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-neutral-900/80 backdrop-blur-sm"
      />

      {/* Main Container */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        transition={{ type: "spring", duration: 0.5 }}
        className="relative flex h-full max-h-[85vh] w-full max-w-4xl flex-col overflow-hidden rounded-3xl border border-slate-150 bg-white text-slate-800 shadow-2xl md:flex-row"
      >
        {/* Visual Preview Section (Left Side) */}
        <div className="flex flex-col justify-between bg-slate-50 p-6 md:w-1/2 md:border-r md:border-slate-100">
          <div>
            <span className="inline-block rounded-full bg-orange-100 px-3 py-1 font-sans text-xs font-semibold tracking-wider text-orange-600 uppercase">
              {item.category}
            </span>
            <h3 className="mt-2 font-display text-2xl font-bold tracking-tight text-slate-900 md:text-3xl">
              Customize {item.name}
            </h3>
            <p className="mt-2 text-sm text-slate-500 leading-relaxed">
              {item.description}
            </p>
            <div className="mt-4 flex items-center gap-4 text-xs font-mono text-slate-400">
              <span className="flex items-center gap-1">
                <Info className="h-3.5 w-3.5 text-orange-500" />
                {item.calories} Calories (Base)
              </span>
            </div>
          </div>

          {/* Dynamic Stack Preview (Only for Burgers and Drinks) */}
          <div className="relative my-8 flex flex-1 items-center justify-center py-4">
            {item.category === "burgers" ? (
              <div className="flex flex-col items-center justify-center w-full max-w-[220px]">
                <AnimatePresence mode="popLayout">
                  {/* Top Bun */}
                  <motion.div
                    layout
                    initial={{ y: -50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: -50, opacity: 0 }}
                    className="z-30 h-10 w-44 rounded-t-full bg-amber-600 border border-amber-700 shadow-md flex items-center justify-center text-amber-100 text-[10px] font-bold"
                  >
                    🥨 SESAME BUN TOP
                  </motion.div>

                  {/* Sauce */}
                  {customs.extraSauce && (
                    <motion.div
                      layout
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.8, opacity: 0 }}
                      className="z-25 -mt-2 h-2.5 w-36 rounded-full bg-orange-500 border border-orange-600 shadow-sm opacity-90"
                      title="Double Sauced"
                    />
                  )}

                  {/* Pickles */}
                  {!customs.excludePickles && (
                    <motion.div
                      layout
                      initial={{ rotate: -5, opacity: 0 }}
                      animate={{ rotate: 0, opacity: 1 }}
                      exit={{ rotate: -5, opacity: 0 }}
                      className="z-20 -mt-2 flex gap-4"
                    >
                      <div className="h-4 w-10 rounded-full bg-emerald-600 border border-emerald-700 shadow-sm" />
                      <div className="h-4 w-10 rounded-full bg-emerald-600 border border-emerald-700 shadow-sm" />
                    </motion.div>
                  )}

                  {/* Onion Rings / Raw Onions */}
                  {!customs.excludeOnions && (
                    <motion.div
                      layout
                      initial={{ scale: 0.9, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.9, opacity: 0 }}
                      className="z-15 -mt-2 h-3.5 w-32 rounded-full border-2 border-amber-100 bg-white/40 shadow-sm"
                    />
                  )}

                  {/* Dynamic Patties and Cheese Layers */}
                  {Array.from({ length: customs.patties || 1 }).map((_, idx) => {
                    const cheesy = customs.cheese && customs.cheese > idx;
                    return (
                      <div key={`patty-layer-${idx}`} className="flex flex-col items-center w-full">
                        {cheesy && (
                          <motion.div
                            layout
                            initial={{ y: -10, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            exit={{ y: -10, opacity: 0 }}
                            className="z-10 -mb-1 h-3 w-40 rounded bg-yellow-400 border border-yellow-500 shadow-sm opacity-95"
                          />
                        )}
                        <motion.div
                          layout
                          initial={{ scale: 0.9, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          exit={{ scale: 0.9, opacity: 0 }}
                          className="z-5 h-7 w-40 rounded-lg bg-yellow-950 border border-neutral-950 shadow-md"
                        />
                      </div>
                    );
                  })}

                  {/* Lettuce */}
                  <motion.div
                    layout
                    className="z-2 -mt-1 h-3 w-42 rounded-full bg-green-500 border border-green-600 shadow-sm"
                  />

                  {/* Bottom Bun */}
                  <motion.div
                    layout
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: 50, opacity: 0 }}
                    className="z-1 h-6 w-44 rounded-b-xl bg-amber-600 border border-amber-700 shadow-sm"
                  />
                </AnimatePresence>
              </div>
            ) : item.category === "beverages" ? (
              <div className="flex flex-col items-center justify-end h-40">
                <div
                  className={`relative rounded-b-full border-2 border-neutral-300 bg-[#FAF9F6]/20 shadow-inner flex flex-col justify-end overflow-hidden transition-all duration-300 ${
                    customs.size === "S" ? "w-24 h-24" : customs.size === "L" ? "w-32 h-36" : "w-28 h-30"
                  }`}
                >
                  {/* Drink Fill depending on item */}
                  <div
                    className={`w-full h-[85%] origin-bottom transition-all duration-500 ${
                      item.id === "byte-cola"
                        ? "bg-[#2b1810]"
                        : item.id === "lemonade"
                        ? "bg-yellow-200"
                        : "bg-pink-100" // Strawberry Velvet shake default color
                    }`}
                  >
                    {/* Ice Cubes inside the drink */}
                    {customs.iceLevel !== "none" && (
                      <div className="absolute inset-0 p-4 flex flex-wrap gap-2 items-start justify-center">
                        <div className="w-4 h-4 rounded bg-white/70 animate-pulse-subtle rotate-12" />
                        <div className="w-3.5 h-3.5 rounded bg-white/60 animate-pulse-subtle -rotate-12" />
                        {customs.iceLevel === "regular" && (
                          <div className="w-4 h-4 rounded bg-white/50 animate-pulse-subtle rotate-45" />
                        )}
                      </div>
                    )}
                  </div>
                  {/* Outer Label */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="rounded-full bg-white/80 px-2 py-0.5 text-[9px] font-mono tracking-wider font-bold text-orange-600 border border-orange-200 uppercase/90">
                      Sizzle Cup &bull; {customs.size}
                    </span>
                  </div>
                </div>
                {/* Straw */}
                <div className="absolute bottom-28 h-20 w-2.5 bg-orange-500 border-l border-white rounded-t" />
              </div>
            ) : (
              // Simple Item Mock Card Preview
              <img
                src={item.image}
                alt={item.name}
                className="h-44 w-60 rounded-2xl object-cover shadow-lg border-2 border-amber-50"
              />
            )}
          </div>

          <div className="hidden font-mono text-[11px] text-neutral-500 md:block">
            * Custom selections dynamically update cook-sheet. Calories vary roughly count.
          </div>
        </div>

        {/* Adjusting Configuration Section (Right Side) */}
        <div className="flex flex-1 flex-col justify-between overflow-y-auto p-6">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 rounded-full bg-neutral-100 p-2 text-neutral-500 hover:bg-neutral-200 hover:text-neutral-700"
          >
            <X className="h-5 w-5" />
          </button>

          {/* Customization Options Scroller */}
          <div className="space-y-6">
            <h4 className="font-display text-sm font-semibold uppercase tracking-wider text-neutral-400">
              Personalize Flavor
            </h4>

            {/* CONDITIONAL CONTROLS */}

            {/* Category: Burger Options */}
            {item.category === "burgers" && (
              <div className="space-y-4">
                {/* Patties */}
                <div className="flex items-center justify-between rounded-2xl border border-neutral-100 bg-white p-3.5 shadow-sm">
                  <div>
                    <h5 className="font-sans text-sm font-semibold text-neutral-900">Beef Patties</h5>
                    <p className="text-xs text-neutral-500">+$1.50 per additional patty</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      disabled={(customs.patties || 1) <= 1}
                      onClick={() => updateProp("patties", (customs.patties || 1) - 1)}
                      className="rounded-xl border border-neutral-200 p-1.5 text-neutral-600 hover:bg-neutral-50 disabled:opacity-30"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="w-6 text-center font-mono font-bold text-neutral-800">
                      {customs.patties || 1}
                    </span>
                    <button
                      disabled={(customs.patties || 1) >= 3}
                      onClick={() => updateProp("patties", (customs.patties || 1) + 1)}
                      className="rounded-xl border border-neutral-200 p-1.5 text-neutral-600 hover:bg-neutral-50 disabled:opacity-30"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                {/* Cheese */}
                <div className="flex items-center justify-between rounded-2xl border border-neutral-100 bg-white p-3.5 shadow-sm">
                  <div>
                    <h5 className="font-sans text-sm font-semibold text-neutral-900">Cheese Slices</h5>
                    <p className="text-xs text-neutral-500">+$0.60 per slice</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      disabled={(customs.cheese || 0) <= 0}
                      onClick={() => updateProp("cheese", (customs.cheese || 0) - 1)}
                      className="rounded-xl border border-neutral-200 p-1.5 text-neutral-600 hover:bg-neutral-50 disabled:opacity-30"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="w-6 text-center font-mono font-bold text-neutral-800">
                      {customs.cheese || 0}
                    </span>
                    <button
                      disabled={(customs.cheese || 0) >= 3}
                      onClick={() => updateProp("cheese", (customs.cheese || 0) + 1)}
                      className="rounded-xl border border-neutral-200 p-1.5 text-neutral-600 hover:bg-neutral-50 disabled:opacity-30"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                {/* Ingredient Toggles */}
                <div className="space-y-2 pt-2">
                  <label className="flex items-center gap-3.5 rounded-xl border border-slate-100 bg-white px-4 py-3 cursor-pointer shadow-xs select-none">
                    <input
                      type="checkbox"
                      checked={!!customs.excludeOnions}
                      onChange={e => updateProp("excludeOnions", e.target.checked)}
                      className="h-4 w-4 rounded border-slate-300 text-orange-500 focus:ring-orange-500"
                    />
                    <span className="text-sm text-slate-700">Hold the Grilled Onions</span>
                  </label>

                  <label className="flex items-center gap-3.5 rounded-xl border border-slate-100 bg-white px-4 py-3 cursor-pointer shadow-xs select-none">
                    <input
                      type="checkbox"
                      checked={!!customs.excludePickles}
                      onChange={e => updateProp("excludePickles", e.target.checked)}
                      className="h-4 w-4 rounded border-slate-300 text-orange-500 focus:ring-orange-500"
                    />
                    <span className="text-sm text-slate-700">Hold the Pickles</span>
                  </label>

                  <label className="flex items-center gap-3.5 rounded-xl border border-slate-100 bg-white px-4 py-3 cursor-pointer shadow-xs select-none">
                    <input
                      type="checkbox"
                      checked={!!customs.extraSauce}
                      onChange={e => updateProp("extraSauce", e.target.checked)}
                      className="h-4 w-4 rounded border-slate-300 text-orange-500 focus:ring-orange-500"
                    />
                    <span className="text-sm text-slate-700">Extra Sizzle Signature Sauce</span>
                  </label>
                </div>
              </div>
            )}

            {/* Category: Sides Options */}
            {item.category === "sides" && (
              <div className="space-y-4">
                {/* Salt Level */}
                <div className="rounded-2xl border border-slate-100 bg-white p-4 shadow-sm">
                  <h5 className="font-sans text-sm font-semibold text-slate-900 mb-3">Salt Seasoning</h5>
                  <div className="grid grid-cols-3 gap-2">
                    {(["regular", "light", "none"] as const).map(option => (
                      <button
                        key={option}
                        onClick={() => updateProp("saltLevel", option)}
                        className={`rounded-xl border py-2 text-xs font-medium uppercase tracking-wider transition-all ${
                          customs.saltLevel === option
                            ? "bg-orange-500 border-orange-500 text-white font-semibold animate-none"
                            : "border-slate-200 text-slate-600 hover:bg-slate-50"
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Cajun Dust Toggle */}
                <label className="flex items-center gap-3.5 rounded-2xl border border-slate-100 bg-white px-4 py-3.5 cursor-pointer shadow-sm select-none">
                  <input
                    type="checkbox"
                    checked={!!customs.spiceDust}
                    onChange={e => updateProp("spiceDust", e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300 text-orange-500 focus:ring-orange-500"
                  />
                  <div>
                    <span className="block text-sm font-semibold text-slate-800">Add Fire Cajun Dust</span>
                    <span className="block text-xs text-slate-505">Toss with cayenne, paprika & house spice</span>
                  </div>
                </label>
              </div>
            )}

            {/* Category: Beverage Options */}
            {item.category === "beverages" && (
              <div className="space-y-4">
                {/* Size Choice */}
                <div className="rounded-2xl border border-neutral-100 bg-white p-4 shadow-sm">
                  <div className="flex justify-between items-center mb-3">
                    <h5 className="font-sans text-sm font-semibold text-neutral-900">Cup Size</h5>
                    <span className="font-mono text-xs text-neutral-500">
                      Small (-$0.30) &bull; Large (+$0.60)
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    {(["S", "M", "L"] as const).map(option => (
                      <button
                        key={option}
                        onClick={() => updateProp("size", option)}
                        className={`rounded-xl border py-2 text-xs font-semibold uppercase tracking-wider transition-all ${
                          customs.size === option
                            ? "bg-amber-600 border-amber-600 text-white"
                            : "border-neutral-200 text-neutral-600 hover:bg-neutral-50"
                        }`}
                      >
                        {option} {option === "S" ? "Sml" : option === "L" ? "Lrg" : "Med"}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Shake Flavor (If Velvet Shake) */}
                {item.id === "velvet-shake" && (
                  <div className="rounded-2xl border border-neutral-100 bg-white p-4 shadow-sm">
                    <h5 className="font-sans text-sm font-semibold text-neutral-900 mb-3">Churn Flavor</h5>
                    <div className="grid grid-cols-3 gap-2">
                      {(["Vanilla", "Chocolate", "Strawberry"] as const).map(flavor => (
                        <button
                          key={flavor}
                          onClick={() => updateProp("shakeFlavor", flavor)}
                          className={`rounded-xl border py-2 text-xs font-semibold transition-all ${
                            customs.shakeFlavor === flavor
                              ? "bg-amber-600 border-amber-600 text-white"
                              : "border-neutral-200 text-neutral-600 hover:bg-neutral-50"
                          }`}
                        >
                          {flavor}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Ice Level */}
                <div className="rounded-2xl border border-neutral-100 bg-white p-4 shadow-sm">
                  <h5 className="font-sans text-sm font-semibold text-neutral-900 mb-3">Ice Cube Volume</h5>
                  <div className="grid grid-cols-3 gap-2">
                    {(["regular", "light", "none"] as const).map(option => (
                      <button
                        key={option}
                        onClick={() => updateProp("iceLevel", option)}
                        className={`rounded-xl border py-2 text-xs font-medium uppercase tracking-wider transition-all ${
                          customs.iceLevel === option
                            ? "bg-amber-600 border-amber-600 text-white font-semibold"
                            : "border-neutral-200 text-neutral-600 hover:bg-neutral-50"
                        }`}
                      >
                        {option}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Category: Desserts Options */}
            {item.category === "desserts" && (
              <div className="space-y-4">
                {/* Extra drizzle toggle */}
                <label className="flex items-center gap-3.5 rounded-2xl border border-slate-100 bg-white px-4 py-4 cursor-pointer shadow-sm select-none">
                  <input
                    type="checkbox"
                    checked={!!customs.extraDrizzle}
                    onChange={e => updateProp("extraDrizzle", e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300 text-orange-500 focus:ring-orange-500"
                  />
                  <div>
                    <span className="block text-sm font-semibold text-slate-800">Extra Rich Sauce Drizzle</span>
                    <span className="block text-xs text-slate-505">+$0.50 &bull; More warm chocolate fudge & caramel drizzle</span>
                  </div>
                </label>
              </div>
            )}
          </div>

          {/* Action Footer: Reset / Quantity / Summary / Add To Cart */}
          <div className="mt-8 border-t border-neutral-100 pt-6 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="block text-xs uppercase tracking-wider text-neutral-400 font-sans font-semibold">
                  Personalized Specs
                </span>
                <span className="block max-w-[280px] truncate text-xs font-medium text-neutral-600">
                  {getCustomizationSummary(item.category, customs)}
                </span>
              </div>

              {/* Reset to Default */}
              <button
                onClick={handleReset}
                className="text-xs font-semibold text-slate-400 underline decoration-dotted underline-offset-4 hover:text-orange-505"
              >
                Reset Specs
              </button>
            </div>

            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between pt-2">
              {/* Quantity Changer */}
              <div className="flex items-center gap-2 rounded-2xl border border-slate-200 bg-white p-1.5 self-start">
                <button
                  disabled={quantity <= 1}
                  onClick={() => setQuantity(prev => prev - 1)}
                  className="rounded-xl p-2 text-slate-500 hover:bg-slate-50 disabled:opacity-30"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="w-8 text-center font-display text-sm font-bold text-slate-800">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(prev => prev + 1)}
                  className="rounded-xl p-2 text-slate-500 hover:bg-slate-50"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>

              {/* Pricing & Checkout Block */}
              <div className="flex flex-1 gap-3.5 sm:justify-end">
                <div className="flex flex-col justify-center sm:text-right pr-2">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded sm:self-end">
                    Total Sizzle Spec
                  </span>
                  <span className="font-mono text-xl font-bold text-slate-900 mt-1">
                    ${totalCost.toFixed(2)}
                  </span>
                </div>

                <button
                  onClick={() => onAddToCart(item, quantity, customs)}
                  className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-orange-500 px-6 py-4 font-sans text-sm font-bold text-white shadow-lg shadow-orange-500/10 transition-all hover:bg-orange-600 active:scale-[0.98] sm:flex-initial"
                >
                  <Check className="h-4 w-4" />
                  Add to Sizzle bag
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
