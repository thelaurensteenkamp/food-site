import { useState, useRef, useEffect } from "react";
import { Message, CartItem } from "../types";
import { Bot, User, Send, Sparkles, AlertCircle, ShoppingBag, Minimize2, Maximize2 } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface AIAssistantProps {
  currentCart: CartItem[];
  onExecuteCartActions: (actions: any[]) => void;
  isOpen: boolean;
  onClose: () => void;
}

export default function AIAssistant({
  currentCart,
  onExecuteCartActions,
  isOpen,
  onClose
}: AIAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome-1",
      role: "assistant",
      text: "Hey there! I'm Sizzly, your gourmet Drive-Thru digital buddy. 🍔✨ Ask me about our signature smash patties, calories, or say 'Add a Sizzle Classic burger and truffle fries' to update your bag immediately!",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorStatus, setErrorStatus] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      setTimeout(scrollToBottom, 150);
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: "user",
      text: textToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    setErrorStatus(null);

    try {
      // Package conversation and send to Express proxy endpoint
      const response = await fetch("/api/assistant/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          messages: [...messages, userMessage].map(msg => ({
            role: msg.role,
            text: msg.text
          })),
          currentCart
        })
      });

      if (!response.ok) {
        throw new Error("Failed to receive a response from Sizzly.");
      }

      const data = await response.json();

      setIsLoading(false);

      if (data.error) {
        throw new Error(data.error);
      }

      // Add Model message to state
      const modelMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: "assistant",
        text: data.reply || "I didn't quite catch that. Could you repeat?",
        timestamp: new Date()
      };

      setMessages(prev => [...prev, modelMessage]);

      // If the model invoked automated cart functions, pass them to parent handler for execution
      if (data.cartActions && data.cartActions.length > 0) {
        onExecuteCartActions(data.cartActions);
      }
    } catch (err: any) {
      setIsLoading(false);
      setErrorStatus(err.message || "Something went wrong.");
      setMessages(prev => [
        ...prev,
        {
          id: `error-${Date.now()}`,
          role: "assistant",
          text: "⚠️ Oh no! My connection to the kitchen got slightly crispy. Please verify you configured your GEMINI_API_KEY inside the 'Settings > Secrets' panel!",
          timestamp: new Date()
        }
      ]);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    handleSendMessage(suggestion);
  };

  const QUICK_SUGGESTIONS = [
    "Add Sizzle Classic burger & fries",
    "What's your spiciest meal?",
    "Recommend a dessert pairing",
    "Customize a Velvet Shake"
  ];

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 30, scale: 0.95 }}
      transition={{ duration: 0.3, type: "spring", damping: 25 }}
      className="fixed bottom-6 right-6 z-40 flex h-[580px] w-full max-w-[420px] flex-col overflow-hidden rounded-3xl border border-slate-100 bg-white text-slate-800 shadow-2xl"
    >
      {/* Dynamic Voice Header */}
      <div className="relative flex items-center justify-between border-b border-orange-100 bg-orange-500 px-5 py-4 text-white shadow-sm">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 border border-white/20">
              <Bot className="h-5 w-5 text-orange-100" />
            </div>
            {/* Pulsing indicator */}
            <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-emerald-400 ring-2 ring-orange-600" />
          </div>
          <div>
            <h4 className="font-display font-bold tracking-tight text-white mb-0.5 flex items-center gap-1.5 text-sm">
              Sizzly Chat AI
              <Sparkles className="h-3.5 w-3.5 text-amber-300 animate-pulse" />
            </h4>
            <span className="block text-[10px] text-amber-100 font-mono tracking-wide uppercase">
              {isLoading ? "Writing order sheet..." : "Ready to serve you"}
            </span>
          </div>
        </div>

        <button
          onClick={onClose}
          className="rounded-xl bg-white/10 p-2 text-white/85 hover:bg-white/20 hover:text-white"
        >
          <Minimize2 className="h-4 w-4" />
        </button>
      </div>

      {/* Messages Conversation Column */}
      <div className="flex-1 overflow-y-auto bg-slate-50/50 p-4 space-y-4">
        <div className="pb-1 text-center font-mono text-[9px] text-slate-400 select-none">
          SYSTEM: SIZZLE SECURE SERVER ENCRYPTED ASSETS ACTIVE
        </div>

        <AnimatePresence initial={false}>
          {messages.map((message) => {
            const isBot = message.role === "assistant";
            return (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                className={`flex gap-3 max-w-[85%] ${isBot ? "" : "ml-auto flex-row-reverse"}`}
              >
                {/* Avatar Icon */}
                <div
                  className={`mt-1 flex h-7.5 w-7.5 shrink-0 items-center justify-center rounded-full outline-hidden border ${
                    isBot
                      ? "bg-orange-50 border-orange-100 text-orange-600"
                      : "bg-slate-100 border-slate-200 text-slate-600"
                  }`}
                >
                  {isBot ? <Bot className="h-4 w-4" /> : <User className="h-4 w-4" />}
                </div>

                {/* Bubble content */}
                <div>
                  <div
                    className={`rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed shadow-xs ${
                      isBot
                        ? "bg-white border border-slate-100 text-slate-850 rounded-tl-none font-sans"
                        : "bg-slate-900 text-white rounded-tr-none font-sans"
                    }`}
                  >
                    {message.text}
                  </div>
                  <span className="block mt-1 font-mono text-[9px] text-slate-400 text-right pr-1">
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>

        {/* Typing thinking indicator */}
        {isLoading && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex gap-3 max-w-[80%]"
          >
            <div className="flex h-7.5 w-7.5 shrink-0 items-center justify-center rounded-full bg-orange-50 border border-orange-100 text-orange-600">
              <Bot className="h-4 w-4" />
            </div>
            <div className="rounded-2xl border border-slate-100 bg-white px-4 py-3 shadow-xs rounded-tl-none">
              <div className="flex items-center gap-1">
                <div className="h-1.5 w-1.5 animate-bounce rounded-full bg-orange-500 [animation-delay:-0.3s]" />
                <div className="h-1.5 w-1.5 animate-bounce rounded-full bg-orange-500 [animation-delay:-0.15s]" />
                <div className="h-1.5 w-1.5 animate-bounce rounded-full bg-orange-500" />
                <span className="ml-2 font-mono text-[10px] text-slate-400">Sizzly is cooking...</span>
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggestion Chips Section */}
      <div className="bg-slate-50 px-4 py-2 flex flex-wrap gap-1.5 border-t border-slate-150 shrink-0">
        {QUICK_SUGGESTIONS.map((suggestion, idx) => (
          <button
            key={`sig-${idx}`}
            onClick={() => handleSuggestionClick(suggestion)}
            className="rounded-full bg-white border border-slate-200 px-2.5 py-1 text-[10px] font-medium text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer select-none shadow-2xs"
          >
            {suggestion}
          </button>
        ))}
      </div>

      {/* Input Message Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage(input);
        }}
        className="flex items-center gap-2 border-t border-slate-100 bg-white p-3.5"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Speak to Sizzly..."
          className="flex-1 bg-slate-50 rounded-xl px-3 py-2 text-xs text-slate-800 outline-hidden hover:bg-slate-100/80 focus:bg-white focus:ring-1 focus:ring-orange-500/30 font-sans border border-slate-100 transition-all"
        />
        <button
          type="submit"
          disabled={!input.trim() || isLoading}
          className="flex h-9 w-9 items-center justify-center rounded-xl bg-orange-500 text-white shadow-md shadow-orange-500/15 hover:bg-orange-600 disabled:opacity-40 disabled:shadow-none transition-all cursor-pointer"
        >
          <Send className="h-4.5 w-4.5" />
        </button>
      </form>
    </motion.div>
  );
}
