import { useState, useEffect } from "react";
import { OrderStatus } from "../types";
import { Check, ClipboardList, Flame, Gift, CheckCircle, Clock, ShoppingCart, ArrowLeft } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface OrderTrackerProps {
  orderStatus: OrderStatus;
  orderItems: any[];
  onResetOrder: () => void;
}

export default function OrderTracker({
  orderStatus,
  orderItems,
  onResetOrder
}: OrderTrackerProps) {
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [tickerMsg, setTickerMsg] = useState("Sanitizing burger tongs & grill surface...");
  const [estimatedMin, setEstimatedMin] = useState(12);

  const STAGES = [
    { title: "Order Logged", desc: "Transmitted straight to kitchen prep screens.", icon: ClipboardList, step: 0 },
    { title: "Grilling & Prep", desc: " Aberdeen patties sizzling, fries double dipping.", icon: Flame, step: 1 },
    { title: "Boxing & Bag", desc: "Placed in thermal insulated craft-bags with care.", icon: Gift, step: 2 },
    { title: "Sizzle Out Counter", desc: "Sizzling hot and ready for your delicious pickup!", icon: CheckCircle, step: 3 }
  ];

  // Gourmet live updates simulator ticker
  const TICKER_MESSAGES = [
    "Steaming artisan sesame brioche buns...",
    "Arranging fresh organic leaf lettuce...",
    "Twice-frying Russet Sizzle Fries...",
    "Grilling Aberdeen beef on flame broiler...",
    "Melting dual aged Cheddar slices...",
    "Whipping velvet strawberry vanilla layers...",
    "Sprinkling rock sea salt caramel on skillet...",
    "Sealing hot insulated bags for insulation...",
    "Checking quality standards: Perfect Burger achieved!"
  ];

  useEffect(() => {
    // Progress steps slowly for simulation
    let stepTimer: NodeJS.Timeout;
    let tickerTimer: NodeJS.Timeout;

    if (orderStatus.active) {
      // Step advancement
      stepTimer = setInterval(() => {
        setCurrentStep(prev => {
          if (prev < 3) {
            // Update estimated minutes
            setEstimatedMin(m => Math.max(2, m - 3));
            return prev + 1;
          }
          return prev;
        });
      }, 15000); // Advance every 15s

      // Custom ticker rotation
      tickerTimer = setInterval(() => {
        const randomIndex = Math.floor(Math.random() * TICKER_MESSAGES.length);
        setTickerMsg(TICKER_MESSAGES[randomIndex]);
      }, 5000); // Change message every 5s
    }

    return () => {
      clearInterval(stepTimer);
      clearInterval(tickerTimer);
    };
  }, [orderStatus.active]);

  const orderTotal = orderItems.reduce((acc, item) => acc + item.price * item.quantity, 0);

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-3xl border border-slate-100 bg-white p-6 shadow-xl"
      >
        <div className="flex flex-col items-center text-center">
          <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-orange-50 border border-orange-100 text-orange-600">
            <Clock className="h-8 w-8 animate-spin-slow text-orange-500" />
            <span className="absolute -top-1 -right-1 flex h-4 w-4">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-4 w-4 bg-orange-500"></span>
            </span>
          </div>

          <h3 className="mt-4 font-display text-2xl font-bold tracking-tight text-slate-900">
            Sizzle Pipeline Active!
          </h3>
          <p className="mt-1 text-sm text-slate-500">
            Order Reference: <strong className="font-mono text-xs text-slate-700">#SIZZLE-{Date.now().toString().slice(-5)}</strong>
          </p>

          {/* Time Countdown Header */}
          <div className="mt-5 rounded-2xl bg-slate-50 border border-slate-100 px-6 py-4">
            <span className="block text-[11px] uppercase tracking-wider text-slate-400 font-sans font-semibold">
              Estimated Prep Pickup
            </span>
            <span className="font-mono text-3xl font-black text-slate-900">
              {currentStep === 3 ? "READY NOW" : `~ ${estimatedMin} MINS`}
            </span>
          </div>

          {/* Gourmet live updating ticker bubble */}
          <div className="mt-4 flex max-w-[320px] items-center gap-2 rounded-full bg-white border border-slate-100 px-4 py-1.5 shadow-xs">
            <span className="flex h-2 w-2 rounded-full bg-orange-500 animate-ping shrink-0" />
            <span className="truncate text-xs text-slate-600 font-sans font-medium">
              Line Update: <span className="text-slate-900 font-semibold">{tickerMsg}</span>
            </span>
          </div>
        </div>

        {/* Pipeline Steps Tracker */}
        <div className="mt-8 relative pl-6 before:absolute before:top-4 before:bottom-4 before:left-[15px] before:w-0.5 before:bg-slate-150">
          {STAGES.map((stage) => {
            const isCompleted = currentStep > stage.step;
            const isActive = currentStep === stage.step;
            const Icon = stage.icon;

            return (
              <div key={stage.step} className="relative mb-6 last:mb-0 flex items-start gap-4">
                {/* Visual Circle Marker */}
                <div
                  className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-slate-100 transition-all ${
                    isCompleted
                      ? "bg-emerald-500 border-emerald-500 text-white"
                      : isActive
                      ? "bg-orange-500 border-orange-500 text-white scale-110 shadow-lg ring-4 ring-orange-50"
                      : "bg-slate-50 text-slate-400"
                  }`}
                >
                  {isCompleted ? <Check className="h-4 w-4" /> : <Icon className="h-4 w-4" />}
                </div>

                {/* Text Description */}
                <div className="pt-0.5">
                  <h4
                    className={`font-display text-sm font-bold tracking-tight ${
                      isCompleted || isActive ? "text-neutral-900" : "text-neutral-400"
                    }`}
                  >
                    {stage.title}
                  </h4>
                  <p className="text-xs text-neutral-500 leading-normal mt-0.5">
                    {stage.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Order details collapsed receipt summary */}
        <div className="mt-8 rounded-2xl border border-slate-100 bg-slate-50/40 p-4">
          <h4 className="flex items-center gap-2 font-display text-xs font-semibold uppercase tracking-wider text-slate-400">
            <ShoppingCart className="h-4 w-4 text-slate-400" />
            Sizzle Receipt
          </h4>
          <div className="mt-3 divide-y divide-slate-100">
            {orderItems.map((item, idx) => (
              <div key={`rc-${idx}`} className="flex justify-between py-2 text-xs text-slate-700">
                <span className="font-sans font-medium">
                  {item.quantity}x {item.name}
                </span>
                <span className="font-mono font-medium text-slate-900">
                  ${(item.price * item.quantity).toFixed(2)}
                </span>
              </div>
            ))}
            <div className="flex justify-between pt-2.5 font-bold font-display text-sm text-slate-900">
              <span>Total Paid</span>
              <span className="font-mono text-orange-600">${orderTotal.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Home actions button */}
        <div className="mt-6 flex justify-center">
          <button
            onClick={onResetOrder}
            className="flex items-center gap-2 rounded-xl bg-neutral-900 px-4 py-2 text-xs font-bold text-white shadow-sm hover:bg-neutral-800 transition-colors"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            Add To Bag / Order More
          </button>
        </div>
      </motion.div>
    </div>
  );
}
