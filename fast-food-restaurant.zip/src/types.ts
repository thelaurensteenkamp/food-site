export interface MenuItem {
  id: string;
  name: string;
  category: "burgers" | "sides" | "beverages" | "desserts";
  price: number;
  description: string;
  calories: number;
  image: string;
  customizationOptions: {
    type: "burgers" | "sides" | "beverages" | "desserts";
    options: string[];
  };
}

export interface BurgerCustomizations {
  patties?: number; // 1, 2, or 3
  cheese?: number;  // 0, 1, 2, or 3
  excludeOnions?: boolean;
  excludePickles?: boolean;
  extraSauce?: boolean;
}

export interface SideCustomizations {
  saltLevel?: "regular" | "light" | "none";
  spiceDust?: boolean;
}

export interface DrinkCustomizations {
  size?: "S" | "M" | "L";
  iceLevel?: "regular" | "light" | "none";
  shakeFlavor?: "Vanilla" | "Chocolate" | "Strawberry";
}

export interface DessertCustomizations {
  extraDrizzle?: boolean;
}

export type ItemCustomizations = BurgerCustomizations &
  SideCustomizations &
  DrinkCustomizations &
  DessertCustomizations;

export interface CartItem {
  uniqueId: string; // custom timestamp + ID to distinguish custom vs classic versions of the same item
  id: string; // item id (e.g., 'classic-burger')
  name: string;
  category: "burgers" | "sides" | "beverages" | "desserts";
  basePrice: number;
  price: number; // dynamically calculated with options
  image: string;
  quantity: number;
  customizations: ItemCustomizations;
}

export interface Message {
  id: string;
  role: "user" | "assistant";
  text: string;
  timestamp: Date;
}

export interface OrderStatus {
  step: "received" | "preparing" | "packaging" | "ready" | "completed";
  estimatedMinutes: number;
  active: boolean;
}
