import { ItemCustomizations } from "./types";

/**
 * Calculates the final price of an item given its customizations.
 */
export function calculateItemPrice(
  basePrice: number,
  category: "burgers" | "sides" | "beverages" | "desserts",
  customizations: ItemCustomizations
): number {
  let finalPrice = basePrice;

  if (category === "burgers") {
    // Patties: default is 1 for classic/garden/spicy, 2 for cheddar-melt
    const extraPatties = (customizations.patties || 1) - 1;
    if (extraPatties > 0) {
      finalPrice += extraPatties * 1.50;
    }
    // Cheese: standard/extra
    const extraCheese = customizations.cheese || 0;
    if (extraCheese > 0) {
      finalPrice += extraCheese * 0.60;
    }
  } else if (category === "beverages") {
    // Size changes
    if (customizations.size === "S") {
      finalPrice -= 0.30;
    } else if (customizations.size === "L") {
      finalPrice += 0.60;
    }
  } else if (category === "desserts") {
    if (customizations.extraDrizzle) {
      finalPrice += 0.50;
    }
  }

  return Number(finalPrice.toFixed(2));
}

/**
 * Generates a beautiful human-readable summary of chose customizations
 */
export function getCustomizationSummary(
  category: "burgers" | "sides" | "beverages" | "desserts",
  customizations: ItemCustomizations
): string {
  const parts: string[] = [];

  if (category === "burgers") {
    if (customizations.patties && customizations.patties > 1) {
      parts.push(`${customizations.patties}x Patties`);
    }
    if (customizations.cheese && customizations.cheese > 0) {
      parts.push(`${customizations.cheese}x Cheddar`);
    } else if (customizations.cheese === 0) {
      parts.push("No Cheese");
    }
    if (customizations.excludeOnions) {
      parts.push("No Onions");
    }
    if (customizations.excludePickles) {
      parts.push("No Pickles");
    }
    if (customizations.extraSauce) {
      parts.push("Extra Sauce");
    }
  } else if (category === "sides") {
    if (customizations.saltLevel && customizations.saltLevel !== "regular") {
      parts.push(`${customizations.saltLevel} salt`);
    }
    if (customizations.spiceDust) {
      parts.push("Cajun Dusted");
    }
  } else if (category === "beverages") {
    if (customizations.size && customizations.size !== "M") {
      parts.push(`Size ${customizations.size}`);
    }
    if (customizations.iceLevel && customizations.iceLevel !== "regular") {
      parts.push(`${customizations.iceLevel} ice`);
    }
    if (customizations.shakeFlavor) {
      parts.push(`${customizations.shakeFlavor} Flavor`);
    }
  } else if (category === "desserts") {
    if (customizations.extraDrizzle) {
      parts.push("Extra Hot Fudge Drizzle");
    }
  }

  return parts.length > 0 ? parts.join(", ") : "Classic Style";
}
