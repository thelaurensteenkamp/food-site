import { useState, useEffect } from "react";
import { MenuItem, CartItem, ItemCustomizations, OrderStatus } from "./types";
import { calculateItemPrice, getCustomizationSummary } from "./utils";
import { FALLBACK_MENU } from "./data";
import MealCustomizer from "./components/MealCustomizer";
import AIAssistant from "./components/AIAssistant";
import OrderTracker from "./components/OrderTracker";
import {
  Flame,
  ShoppingBag,
  Bot,
  Sparkles,
  Plus,
  Trash2,
  ChevronRight,
  X,
  MapPin,
  Clock,
  Phone,
  Info,
  Check,
  AlertCircle
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [menu, setMenu] = useState<MenuItem[]>(FALLBACK_MENU);
  const [activeCategory, setActiveCategory] = useState<"burgers" | "sides" | "beverages" | "desserts" | "all">("all");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customizingItem, setCustomizingItem] = useState<MenuItem | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Active Order tracking info
  const [activeOrder, setActiveOrder] = useState<OrderStatus>({
    step: "received",
    estimatedMinutes: 12,
    active: false
  });
  const [orderedItems, setOrderedItems] = useState<CartItem[]>([]);

  // Delivery / Checkout details
  const [tipSelection, setTipSelection] = useState<number>(3); // 3 dollar default tip
  const [isLoadingMenu, setIsLoadingMenu] = useState(false);

  // Load menu items from server-side Express endpoint
  useEffect(() => {
    setIsLoadingMenu(true);
    fetch("/api/menu")
      .then(res => res.json())
      .then(data => {
        if (data.menu) {
          setMenu(data.menu);
        }
        setIsLoadingMenu(false);
      })
      .catch(err => {
        console.error("Failed to load backend menu, falling back to static items.", err);
        setMenu(FALLBACK_MENU);
        setIsLoadingMenu(false);
      });
  }, []);

  // Show a custom toast notifier alert easily
  const triggerToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => {
      setToastMsg((current) => (current === msg ? null : current));
    }, 4500);
  };

  // Add customized item block to shopping cart
  const handleAddToCart = (item: MenuItem, quantity: number, customizations: ItemCustomizations) => {
    const finalPrice = calculateItemPrice(item.price, item.category, customizations);

    // Create a unique hash to distinguish same-id items with distinct adjustments
    const customizationHash = JSON.stringify(customizations);
    const uniqueId = `${item.id}-${customizationHash}`;

    setCart(prev => {
      const idx = prev.findIndex(c => c.uniqueId === uniqueId);
      if (idx > -1) {
        // Increment quantity if identical customizations already exist
        const updated = [...prev];
        updated[idx].quantity += quantity;
        return updated;
      } else {
        // Insert new customization record
        return [
          ...prev,
          {
            uniqueId,
            id: item.id,
            name: item.name,
            category: item.category,
            basePrice: item.price,
            price: finalPrice,
            image: item.image,
            quantity,
            customizations
          }
        ];
      }
    });

    setCustomizingItem(null);
    triggerToast(`Added ${quantity}x ${item.name} to Sizzle bag!`);
  };

  // Add Classic (unamended) version of an item straight to the cart
  const handleAddClassicToCart = (item: MenuItem) => {
    const defaultCustoms: ItemCustomizations = {};
    if (item.category === "burgers") {
      defaultCustoms.patties = item.id === "cheese-burger" ? 2 : 1;
      defaultCustoms.cheese = item.id === "cheese-burger" ? 2 : (item.id === "spicy-burger" ? 1 : 1);
      defaultCustoms.excludeOnions = false;
      defaultCustoms.excludePickles = false;
      defaultCustoms.extraSauce = false;
    } else if (item.category === "sides") {
      defaultCustoms.saltLevel = "regular";
      defaultCustoms.spiceDust = false;
    } else if (item.category === "beverages") {
      defaultCustoms.size = "M";
      defaultCustoms.iceLevel = "regular";
      if (item.id === "velvet-shake") {
        defaultCustoms.shakeFlavor = "Vanilla";
      }
    } else if (item.category === "desserts") {
      defaultCustoms.extraDrizzle = false;
    }

    handleAddToCart(item, 1, defaultCustoms);
  };

  const handleRemoveFromCart = (uniqueId: string, name: string) => {
    setCart(prev => prev.filter(c => c.uniqueId !== uniqueId));
    triggerToast(`Removed ${name} from your order.`);
  };

  // Handle smart drive-thru AI assistant action requests
  const handleExecuteCartActions = (actions: any[]) => {
    if (!menu || menu.length === 0) return;

    actions.forEach(act => {
      if (act.type === "ADD") {
        const matchingMenuItem = menu.find(m => m.id === act.itemId);
        if (matchingMenuItem) {
          // Merge model defaults with requested modifications
          const itemCustoms: ItemCustomizations = { ...act.customizations };

          // Build item default gaps dynamically
          if (matchingMenuItem.category === "burgers") {
            if (itemCustoms.patties === undefined) itemCustoms.patties = matchingMenuItem.id === "cheese-burger" ? 2 : 1;
            if (itemCustoms.cheese === undefined) itemCustoms.cheese = matchingMenuItem.id === "cheese-burger" ? 2 : 1;
            if (itemCustoms.excludeOnions === undefined) itemCustoms.excludeOnions = false;
            if (itemCustoms.excludePickles === undefined) itemCustoms.excludePickles = false;
            if (itemCustoms.extraSauce === undefined) itemCustoms.extraSauce = false;
          } else if (matchingMenuItem.category === "sides") {
            if (itemCustoms.saltLevel === undefined) itemCustoms.saltLevel = "regular";
            if (itemCustoms.spiceDust === undefined) itemCustoms.spiceDust = false;
          } else if (matchingMenuItem.category === "beverages") {
            if (itemCustoms.size === undefined) itemCustoms.size = "M";
            if (itemCustoms.iceLevel === undefined) itemCustoms.iceLevel = "regular";
            if (matchingMenuItem.id === "velvet-shake" && itemCustoms.shakeFlavor === undefined) itemCustoms.shakeFlavor = "Vanilla";
          } else if (matchingMenuItem.category === "desserts") {
            if (itemCustoms.extraDrizzle === undefined) itemCustoms.extraDrizzle = false;
          }

          handleAddToCart(matchingMenuItem, act.quantity || 1, itemCustoms);
          triggerToast(`🤖 Sizzly AI added ${act.quantity || 1}x ${matchingMenuItem.name}!`);
        }
      } else if (act.type === "REMOVE") {
        setCart(prev => {
          const removed = prev.find(c => c.id === act.itemId);
          if (removed) {
            triggerToast(`🤖 Sizzly AI removed ${removed.name}.`);
            return prev.filter(c => c.id !== act.itemId);
          }
          return prev;
        });
      } else if (act.type === "CLEAR") {
        setCart([]);
        triggerToast("🤖 Sizzly AI cleared your shopping bag.");
      }
    });
  };

  // Checkout process trigger
  const handleCheckout = () => {
    if (cart.length === 0) return;
    setOrderedItems([...cart]);
    setCart([]);
    setIsCartOpen(false);
    setActiveOrder({
      step: "received",
      estimatedMinutes: 12,
      active: true
    });
    triggerToast("✨ Order transmitted successfully! Watch chef prepare in the tracker.");
  };

  // Pricing summary calculations
  const subtotal = cart.reduce((acc, c) => acc + (c.price * c.quantity), 0);
  const tax = Number((subtotal * 0.0825).toFixed(2)); // 8.25% sales tax
  const checkoutTotal = Number((subtotal + tax + tipSelection).toFixed(2));

  // Category listing selectors
  const categories = [
    { id: "all", label: "Full Sizzle Menu", icon: Flame },
    { id: "burgers", label: "Smash Burgers", icon: Flame },
    { id: "sides", label: "Crispy Sides", icon: Flame },
    { id: "beverages", label: "Cold Drinks", icon: Flame },
    { id: "desserts", label: "Sweet Treats", icon: Flame }
  ];

  const filteredMenu = activeCategory === "all"
    ? menu
    : menu.filter(item => item.category === activeCategory);

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-sans text-slate-900 transition-colors selection:bg-orange-200">
      
      {/* Dynamic Toast Prompt Overlay */}
      <AnimatePresence>
        {toastMsg && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className="fixed top-5 left-1/2 z-50 flex -translate-x-1/2 items-center gap-3 rounded-2xl bg-neutral-900 px-5 py-3.5 text-xs font-semibold text-white shadow-xl max-w-sm"
          >
            <Sparkles className="h-4.5 w-4.5 text-orange-400 shrink-0" />
            <span>{toastMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Modern Retro Brand Banner */}
      <header className="sticky top-0 z-30 border-b border-slate-100 bg-white/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 md:px-6">
          <div className="flex items-center gap-2.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-orange-500 text-white font-bold text-xl shadow-sm">
              F
            </span>
            <div>
              <h1 className="font-display text-lg font-black tracking-tight text-slate-900 md:text-xl">
                SIZZLE<span className="text-orange-500">FRY</span>
              </h1>
              <span className="block text-[9px] font-mono tracking-wider text-orange-600 uppercase/90 font-bold">
                Gourmet Flame-Grill Co.
              </span>
            </div>
          </div>

          {/* Sizzle Info Bar */}
          <div className="hidden items-center gap-6 text-xs text-slate-500 md:flex">
            <span className="flex items-center gap-1.5 font-medium">
              <MapPin className="h-4 w-4 text-orange-500" />
              128 Byte Boulevard
            </span>
            <span className="flex items-center gap-1.5 font-medium">
              <Clock className="h-4 w-4 text-orange-500" />
              11:00 AM - 11:00 PM
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* AI Floating Toggle */}
            <button
              onClick={() => setIsChatOpen(!isChatOpen)}
              className="relative flex items-center gap-1.5 rounded-xl bg-orange-50 border border-orange-100 px-3.5 py-2.5 font-sans text-xs font-bold text-orange-650 shadow-sm transition-all hover:bg-orange-100 cursor-pointer"
            >
              <Bot className="h-4 w-4" />
              <span className="hidden sm:inline">Order Assistant</span>
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-orange-500"></span>
              </span>
            </button>

            {/* Shopping cart bag trigger */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="relative flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2.5 text-xs font-bold text-white shadow-md hover:bg-slate-800 cursor-pointer"
            >
              <ShoppingBag className="h-4 w-4 text-orange-200" />
              <span>Drive-Thru Bag</span>
              {cart.length > 0 && (
                <span className="flex h-5 w-5 items-center justify-center rounded-md bg-orange-500 text-[10px] font-bold text-white font-mono shadow-inner">
                  {cart.reduce((s, c) => s + c.quantity, 0)}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Column */}
      <main className="mx-auto max-w-7xl px-4 py-6 md:px-6 md:py-10">
        
        {/* If Active Order is being prepared, show Tracker View */}
        <AnimatePresence mode="wait">
          {activeOrder.active ? (
            <motion.div
              key="tracker-view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
            >
              <OrderTracker
                orderStatus={activeOrder}
                orderItems={orderedItems}
                onResetOrder={() => {
                  setActiveOrder({ ...activeOrder, active: false });
                }}
              />
            </motion.div>
          ) : (
            <motion.div
              key="menu-explorer-view"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              
              {/* Promo Banner Board */}
              <div className="relative overflow-hidden rounded-3xl bg-white border border-slate-100 p-6 md:p-10 shadow-xs flex flex-col md:flex-row items-center justify-between gap-6">
                {/* Decorative glow bubbles */}
                <div className="absolute -right-10 -top-10 h-60 w-60 rounded-full bg-orange-100 blur-3xl opacity-50" />
                <div className="absolute -left-10 -bottom-10 h-60 w-60 rounded-full bg-slate-100 blur-3xl opacity-50" />

                <div className="relative space-y-5 max-w-xl z-10">
                  <span className="inline-block px-4 py-1.5 bg-orange-100 text-orange-600 rounded-full text-xs font-bold tracking-wide uppercase">
                    #1 Rated Burger in town &bull; Warm & Fresh
                  </span>
                  <h2 className="font-display text-4xl sm:text-5xl font-black leading-[1.1] text-slate-900">
                    Bolder Flavors. <br/>
                    <span className="text-orange-500">Better Fuel.</span>
                  </h2>
                  <p className="text-sm text-slate-500 leading-relaxed font-sans max-w-md">
                    Hand-crafted burgers made with 100% grass-fed beef, artisanal brioche buns, and our secret signature sauce. Delivered to your door in 20 minutes.
                  </p>
                  <div className="flex flex-wrap gap-4 pt-1">
                    <button
                      onClick={() => setIsChatOpen(true)}
                      className="flex items-center gap-1.5 rounded-xl bg-orange-500 px-6 py-3.5 font-sans text-xs font-bold text-white shadow-lg shadow-orange-500/10 hover:bg-orange-600 transition-all cursor-pointer"
                    >
                      <Sparkles className="h-4 w-4" />
                      Chat With Sizzly Drive-Thru
                    </button>
                  </div>
                </div>
                <div className="relative hidden w-64 lg:block shrink-0 z-10">
                  <img
                    src="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=500&q=80"
                    alt="Burger Promo"
                    className="rounded-2xl shadow-xl object-cover h-36 border border-slate-100 rotate-2"
                  />
                  <div className="absolute -bottom-3 -left-3 rounded-xl bg-slate-900 px-2.5 py-1 text-[10px] font-mono font-bold uppercase tracking-wider text-white">
                    From $6.99
                  </div>
                </div>
              </div>

              {/* Category selector row */}
              <div className="flex overflow-x-auto pb-2 scrollbar-none gap-2 shrink-0 md:justify-center">
                {categories.map((cat) => {
                  const Icon = cat.icon;
                  const isSelected = activeCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => setActiveCategory(cat.id as any)}
                      className={`flex items-center gap-2 rounded-2xl px-5 py-3 text-xs font-bold tracking-tight border select-none whitespace-nowrap transition-all cursor-pointer ${
                        isSelected
                          ? "bg-orange-500 border-orange-500 text-white shadow-lg shadow-orange-500/10 scale-[1.03]"
                          : "bg-white border-slate-200 hover:border-slate-350 hover:bg-slate-50 text-slate-600"
                      }`}
                    >
                      <span className={`rounded-md p-1 ${isSelected ? "text-orange-200" : "text-orange-500"}`}>
                        <Icon className="h-4 w-4" />
                      </span>
                      {cat.label}
                    </button>
                  );
                })}
              </div>

              {/* Menu Items Grid Column */}
              <div className="space-y-6">
                <div>
                  <h3 className="font-display text-xl font-extrabold tracking-tight text-slate-900 capitalize">
                    {activeCategory === "all" ? "Our Chef's Choice" : `${activeCategory} Specials`}
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Order classic style, or click "Customize Specs" to calibrate patties, cheese slices, and seasoning configurations.
                  </p>
                </div>

                {isLoadingMenu ? (
                  <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3">
                    {Array.from({ length: 6 }).map((_, idx) => (
                      <div key={idx} className="h-80 animate-pulse rounded-3xl bg-slate-250" />
                    ))}
                  </div>
                ) : filteredMenu.length === 0 ? (
                  <div className="flex flex-col items-center justify-center border border-dashed border-slate-200 rounded-3xl p-10 bg-white text-center">
                    <Bot className="h-10 w-10 text-slate-400 mb-2 animate-bounce" />
                    <p className="text-sm font-semibold text-slate-600">No items detected on the counter.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    {filteredMenu.map((item) => (
                      <motion.div
                        layout
                        key={item.id}
                        initial={{ opacity: 0, scale: 0.97 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ duration: 0.4 }}
                        className="group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-slate-100 bg-white p-4.5 shadow-xs transition-transform hover:shadow-lg"
                      >
                        {/* Calories Stamp */}
                        <div className="absolute top-7 left-7 z-10 rounded-full bg-slate-900/80 px-2.5 py-1 text-[9px] font-mono tracking-wider text-white backdrop-blur-xs select-none lowercase">
                          {item.calories} kcal
                        </div>

                        {/* Image Header with scale effect */}
                        <div className="relative h-44 w-full overflow-hidden rounded-2xl bg-slate-50">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                            referrerPolicy="no-referrer"
                          />
                        </div>

                        {/* Text Block */}
                        <div className="mt-4 flex-1 flex flex-col justify-between">
                          <div>
                            <div className="flex items-start justify-between">
                              <h4 className="font-display text-base font-bold tracking-tight text-slate-900 group-hover:text-orange-600 transition-colors">
                                {item.name}
                              </h4>
                              <span className="font-mono text-base font-extrabold text-slate-950 pr-0.5">
                                ${item.price.toFixed(2)}
                              </span>
                            </div>
                            <p className="mt-1.5 text-xs text-slate-500 line-clamp-2 leading-relaxed">
                              {item.description}
                            </p>
                          </div>

                          {/* Quick Actions Footer */}
                          <div className="mt-5 flex gap-2">
                            {/* Customize Details Button */}
                            <button
                              onClick={() => setCustomizingItem(item)}
                              className="flex-1 rounded-xl border border-slate-200 bg-white px-2 py-2.5 text-center font-sans text-xs font-semibold text-slate-700 hover:bg-slate-50 cursor-pointer transition-all uppercase tracking-wider"
                            >
                              Customize Specs
                            </button>

                            {/* Add Classic Button */}
                            <button
                              onClick={() => handleAddClassicToCart(item)}
                              className="flex h-9.5 w-9.5 shrink-0 items-center justify-center rounded-xl bg-slate-900 text-white shadow-md hover:bg-slate-800 cursor-pointer active:scale-95 transition-all"
                              title="Add Classic uncustomized item"
                            >
                              <Plus className="h-5 w-5" />
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* FOOTER */}
      <footer className="mt-16 border-t border-slate-100 bg-white py-12 text-center text-slate-500">
        <div className="mx-auto max-w-7xl px-4 space-y-4">
          <div className="flex items-center justify-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded bg-orange-100 text-orange-605">
              <Flame className="h-4.5 w-4.5 text-orange-500" />
            </span>
            <span className="font-display font-black tracking-tight text-slate-900 text-sm">
              SIZZLE & FRY GOURMET CO.
            </span>
          </div>
          <p className="text-[11px] text-slate-400 font-mono tracking-wide uppercase select-none">
            Powered by server-side Gemini AI &bull; Aberdeenshire Grass Fed Patties &bull; Idaho Russets
          </p>
          <div className="text-[10px] text-slate-400">
            &copy; 2026 Sizzle & Fry Fast Food Co. All rights reserved. Registered Drive-Thru.
          </div>
        </div>
      </footer>

      {/* SLIDEOUT RIGHT MENU DRAWER: SHOPPING DRIVE-THRU BAG */}
      <AnimatePresence>
        {isCartOpen && (
          <div className="fixed inset-0 z-50 flex justify-end">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-xs"
            />

            {/* Drawer Body Panel */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "tween", duration: 0.35 }}
              className="relative flex h-full w-full max-w-md flex-col bg-white text-slate-800 shadow-2xl border-l border-slate-100"
            >
              <div className="flex items-center justify-between border-b border-slate-100 px-5 py-5 bg-white">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="h-5 w-5 text-orange-500" />
                  <h3 className="font-display text-lg font-bold tracking-tight text-slate-900">
                    Your Sizzle Bag
                  </h3>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="rounded-full bg-slate-150 p-1.5 text-slate-500 hover:bg-slate-200 hover:text-slate-705 cursor-pointer"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Items List Scroll Column */}
              <div className="flex-1 overflow-y-auto p-5 space-y-4">
                {cart.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full py-10 text-center">
                    <div className="rounded-full bg-orange-50 p-4 border border-orange-100 text-orange-600 mb-3 animate-pulse">
                      <ShoppingBag className="h-8 w-8" />
                    </div>
                    <p className="font-display text-sm font-bold text-slate-900">Your bag is empty.</p>
                    <p className="text-xs text-slate-400 max-w-[200px] mt-1 leading-relaxed">
                      Add classical items or speak with Sizzly AI to build your gourmet feast.
                    </p>
                  </div>
                ) : (
                  cart.map((c) => (
                    <div
                      key={c.uniqueId}
                      className="flex gap-3.5 rounded-2xl border border-slate-100 bg-white p-3 shadow-xs"
                    >
                      <img
                        src={c.image}
                        alt={c.name}
                        className="h-16 w-16 rounded-xl object-cover shrink-0 border border-slate-100"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1 flex flex-col justify-between">
                        <div>
                          <div className="flex items-start justify-between">
                            <h4 className="font-display text-sm font-bold tracking-tight text-slate-900">
                              {c.quantity}x {c.name}
                            </h4>
                            <span className="font-mono text-sm font-semibold text-slate-950">
                              ${(c.price * c.quantity).toFixed(2)}
                            </span>
                          </div>
                          {/* Selected Customization Summary */}
                          <p className="text-[10px] text-slate-500 font-sans leading-normal font-medium mt-0.5">
                            {getCustomizationSummary(c.category, c.customizations)}
                          </p>
                        </div>

                        <div className="flex items-center justify-between mt-2.5">
                          {/* Unit Cost Tag */}
                          <span className="font-mono text-[10px] text-slate-400">
                            Unit Cost: ${c.price.toFixed(2)}
                          </span>

                          {/* Delete Item button */}
                          <button
                            onClick={() => handleRemoveFromCart(c.uniqueId, c.name)}
                            className="rounded p-1 text-slate-400 hover:bg-orange-50 hover:text-orange-500 cursor-pointer"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Pricing breakdown & checkout parameters (Only visible if items exist) */}
              {cart.length > 0 && (
                <div className="border-t border-slate-100 bg-white p-5 space-y-4 shadow-[0_-10px_20px_rgba(0,0,0,0.02)]">
                  
                  {/* Tip Grilling Team Selection */}
                  <div>
                    <span className="block text-[10px] uppercase font-mono tracking-wider text-slate-400 mb-2 font-semibold">
                      Support Chef Grilling Team Tip
                    </span>
                    <div className="grid grid-cols-4 gap-1.5 text-center">
                      {([0, 1.50, 3.00, 5.00] as const).map(tipVal => (
                        <button
                          key={tipVal}
                          onClick={() => setTipSelection(tipVal)}
                          className={`rounded-xl border py-1.5 text-xs font-mono font-medium transition-all ${
                            tipSelection === tipVal
                              ? "bg-orange-500 border-orange-500 font-bold text-white shadow-xs"
                              : "border-slate-200 text-slate-600 hover:bg-slate-50"
                          }`}
                        >
                          {tipVal === 0 ? "No" : `$${tipVal.toFixed(2)}`}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Calculations Details block */}
                  <div className="space-y-2 border-t border-slate-100 pt-3 text-xs text-slate-600">
                    <div className="flex justify-between">
                      <span>Chef Subtotal</span>
                      <span className="font-mono font-medium text-slate-905">${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Grill Tax (8.25%)</span>
                      <span className="font-mono font-medium text-slate-905">${tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Kitchen Tip Added</span>
                      <span className="font-mono font-medium text-slate-905">${tipSelection.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between border-t border-slate-100 pt-2 font-display text-sm font-bold text-slate-900">
                      <span>Gourmet Grand Total</span>
                      <span className="font-mono text-orange-600">${checkoutTotal.toFixed(2)}</span>
                    </div>
                  </div>

                  {/* Checkout Button */}
                  <button
                    onClick={handleCheckout}
                    className="flex w-full items-center justify-center gap-2 rounded-2xl bg-orange-500 py-4 font-sans text-sm font-bold text-white shadow-lg shadow-orange-500/10 hover:bg-orange-600 cursor-pointer active:scale-[0.99] transition-all"
                  >
                    <span>Send Order to Flame Grill</span>
                    <ChevronRight className="h-4.5 w-4.5" />
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* DETACHED PERSISTENT AI CHATBOX WRAPPER CHIP (Fades when Chat is closed) */}
      <AnimatePresence>
        {!isChatOpen && !activeOrder.active && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={() => setIsChatOpen(true)}
            className="fixed bottom-6 right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-orange-500 text-white shadow-2xl shadow-orange-500/35 hover:bg-orange-600 hover:scale-[1.05] active:scale-95 transition-all outline-hidden cursor-pointer"
            title="Sizzly Drive-Thru Automated Helper"
          >
            <Bot className="h-6.5 w-6.5 text-orange-200" />
            <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-yellow-400"></span>
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Floating active Customization Modal Panel */}
      <AnimatePresence>
        {customizingItem && (
          <MealCustomizer
            item={customizingItem}
            onClose={() => setCustomizingItem(null)}
            onAddToCart={handleAddToCart}
          />
        )}
      </AnimatePresence>

      {/* Dynamic Sizzly Chat Screen Widget */}
      <AIAssistant
        currentCart={cart}
        onExecuteCartActions={handleExecuteCartActions}
        isOpen={isChatOpen}
        onClose={() => setIsChatOpen(false)}
      />

    </div>
  );
}
